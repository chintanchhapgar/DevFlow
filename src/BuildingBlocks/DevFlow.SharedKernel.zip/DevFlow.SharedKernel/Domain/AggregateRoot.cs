using DevFlow.SharedKernel.Abstractions;

namespace DevFlow.SharedKernel.Domain;

/// <summary>
/// Base class for aggregate roots.
/// Aggregate roots are the only entities accessed directly by repositories.
/// </summary>
/// <typeparam name="TId">Strongly typed identifier.</typeparam>
public abstract class AggregateRoot<TId> : Entity<TId>
    where TId : notnull
{
}
