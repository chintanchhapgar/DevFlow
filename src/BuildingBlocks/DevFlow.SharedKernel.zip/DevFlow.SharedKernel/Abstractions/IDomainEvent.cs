namespace DevFlow.SharedKernel.Abstractions;

/// <summary>
/// Represents a domain event raised by an aggregate.
/// </summary>
public interface IDomainEvent
{
}
